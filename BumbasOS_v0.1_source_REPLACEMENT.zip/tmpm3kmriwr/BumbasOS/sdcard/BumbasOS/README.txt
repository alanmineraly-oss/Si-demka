BumbasOS data folder
notes/   - saved notes
mantis/  - mantis species notes
backups/ - backups
lessons/ - learning materials
games/   - future game data
